/**
 * Created by Genesis on 4/4/2016.
 */
public class BankAccount
{
    private double balance;

    public BankAccount(double b)
    {
        balance = b;

    }

    public BankAccount(BankAccount obj)
    {
        balance = obj.balance;
    }



    public double getBalance()
    {
        return balance;
    }


}
